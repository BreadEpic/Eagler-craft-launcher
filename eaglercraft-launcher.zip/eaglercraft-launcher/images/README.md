# images

Drop your two banners in here with these exact names:

| File | Where it shows |
|---|---|
| `vanilla-banner.png` | top of the Vanilla tab |
| `modded-banner.png` | top of the Modded tab |

The launcher checks for the `.png` first. If it isn't there, it falls back to
the placeholder `.svg` files already in this folder, so nothing looks broken
before you add yours.

**Size:** anything wide works, but around 1920×520 looks best. The banner area
is 210px tall and crops from the centre. Text sits over the left third, so
keep the important part of the image on the right side.

Mod icons go in `images/mods/` if you want them. Reference one from
`data/mods.js` with `icon: "images/mods/whatever.png"`. 40×40 or larger,
square.

File names are case sensitive once this is on GitHub Pages. `Banner.PNG`
will not load if the code asks for `banner.png`.
