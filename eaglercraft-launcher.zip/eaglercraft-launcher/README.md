# Eaglercraft Launcher

A static launcher page with two sections: **Vanilla** and **Modded**. Modded
has a mod browser with search, tag filters, and drag-and-drop importing.

No build step, no dependencies, no server. Upload the folder and it runs.

---

## Put it online

1. Make a new repo on GitHub.
2. Upload everything in this folder to the **root** of the repo (not inside a
   subfolder, or every path will be off by one).
3. Repo **Settings → Pages → Source: Deploy from a branch**, pick `main` and
   `/ (root)`, save.
4. Wait a minute, then open `https://yourname.github.io/your-repo/`.

The `.nojekyll` file is already included. Leave it there — without it GitHub
ignores folders that start with an underscore.

---

## Add your files

### Game versions → `versions/`

Each version gets its own folder with its `index.html` at the top:

```
versions/eaglercraft-1.8/index.html
versions/eaglercraft-1.12.2/index.html
versions/eaglercraft-26.1.2/index.html
versions/eaglerforge/index.html
```

All four folders already have a placeholder page. Replace the whole folder
contents with the real game files. Then check `data/versions.js` — the four
entries are already written, you only need to touch it if you rename a folder
or add a fifth version.

Keep folder names lowercase. GitHub Pages is case sensitive and this is the
single most common reason a version won't open.

### Banners → `images/`

Two files, exact names: `vanilla-banner.png` and `modded-banner.png`.
See `images/README.md` for sizing.

### Mods → `mods/`

Drop the `.js` files in, then add an entry per mod in `data/mods.js`.
See `mods/README.md` for the format.

---

## How mods get to EaglerForge

When you press Play on the Modded tab, the launcher does three things:

1. Writes your selected mods to `localStorage` under `eaglerforge:mods`
2. Appends `?mods=path1,path2` to the game URL
3. Sends a `postMessage` to the game frame once it loads

`versions/eaglerforge/mod-bridge.js` reads whichever of those is available and
injects each mod as a `<script>` tag, in the order you added them. Include it
in your EaglerForge `index.html`, in the `<head>`, before the game scripts:

```html
<script src="mod-bridge.js"></script>
```

**Heads up:** EaglerForge builds differ in how they expect mods to be handed
over. Some want a global array, some want files dropped on a zone, some have
their own loader. If yours doesn't pick the mods up, the `deliver()` function
at the bottom of `mod-bridge.js` is the only part you need to rewrite — the
list is already parsed and sitting there for you.

---

## Files

```
index.html              the launcher
assets/css/launcher.css all the styling
assets/js/launcher.js   all the logic
assets/fonts/           drop pixel.ttf or pixel.woff2 here for a pixel font
data/versions.js        ← edit to add versions
data/mods.js            ← edit to add mods
images/                 ← your banners
mods/                   ← your mod .js files
versions/               ← your game builds
```

You should only ever need to edit the two files in `data/`.

---

## Settings

The Settings button in the sidebar has:

- **Open games in the launcher** — off means each game opens in a new tab
- **Remember my last version** — reopens on whatever you played last
- **Reset launcher data** — clears added mods, imported files, settings

Nothing here touches your Eaglercraft world saves. Those live in the game's
own storage.

---

## A pixel font

The launcher uses a monospace fallback out of the box. If you want a blocky
font, put a `.ttf` or `.woff2` at `assets/fonts/pixel.ttf` (or `.woff2`) and
it gets picked up with no other changes. Use a font you're allowed to
redistribute — [Silkscreen](https://fonts.google.com/specimen/Silkscreen) and
[Press Start 2P](https://fonts.google.com/specimen/Press+Start+2P) are both
open licensed and look right for this.

---

## Notes

- This is a launcher shell only. It ships no game code and no game assets.
- Not affiliated with or endorsed by Mojang or Microsoft.
- Imported mods (drag-and-drop) live in your browser's storage, so they're
  personal to you. Mods listed in `data/mods.js` are visible to everyone.
