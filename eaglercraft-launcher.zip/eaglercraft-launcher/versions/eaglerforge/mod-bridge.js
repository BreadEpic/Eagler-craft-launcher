/* ============================================================================
   mod-bridge.js
   ----------------------------------------------------------------------------
   Put this in your EaglerForge page, in the <head>, BEFORE the game scripts:

       <script src="mod-bridge.js"></script>

   What it does: the launcher writes your chosen mods to localStorage under
   "eaglerforge:mods" right before it opens the game. This file reads that
   list and injects each mod as a <script> tag.

   Every EaglerForge build hooks mods slightly differently. If yours expects
   mods somewhere else (a global array, a drag-and-drop zone, an init
   callback), edit the deliver() function at the bottom. That is the only
   part you should need to change.
   ========================================================================== */

(function () {
  "use strict";

  var STORE_KEY = "eaglerforge:mods";

  /* ---- read the list -------------------------------------------------- */

  function fromStorage() {
    try {
      var raw = localStorage.getItem(STORE_KEY);
      var list = raw ? JSON.parse(raw) : [];
      return Array.isArray(list) ? list : [];
    } catch (e) { return []; }
  }

  function fromQuery() {
    var match = /[?&]mods=([^&]+)/.exec(location.search);
    if (!match) return [];
    return decodeURIComponent(match[1])
      .split(",")
      .filter(Boolean)
      .map(function (src) { return { id: src, name: src, src: src }; });
  }

  /* Storage wins because it carries imported mods that have no file path.
     The query string is the fallback for when storage is blocked. */
  var mods = fromStorage();
  if (!mods.length) mods = fromQuery();

  /* ---- also accept mods pushed in by the launcher iframe --------------- */

  window.addEventListener("message", function (e) {
    if (!e.data || e.data.type !== "eagler-launcher:mods") return;
    if (Array.isArray(e.data.mods) && e.data.mods.length && !window.EaglerForgeMods) {
      deliver(e.data.mods);
    }
  });

  /* ---- hand them to the game ------------------------------------------ */

  function deliver(list) {
    window.EaglerForgeMods = list;

    list.forEach(function (mod) {
      var tag = document.createElement("script");
      if (mod.src) {
        /* mod files sit one level up in /mods, so paths are relative to the
           launcher root, not to this folder */
        tag.src = "../../" + mod.src;
      } else if (mod.code) {
        tag.textContent = mod.code;
      } else {
        return;
      }
      tag.dataset.mod = mod.id || mod.name || "";
      tag.async = false;                 // keep the order the user chose
      (document.head || document.documentElement).appendChild(tag);
    });

    console.log("[launcher] loaded " + list.length + " mod(s)");
  }

  if (mods.length) deliver(mods);
})();
