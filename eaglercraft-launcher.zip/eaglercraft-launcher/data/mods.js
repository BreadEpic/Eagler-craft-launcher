/* ============================================================================
   MOD CATALOG
   ----------------------------------------------------------------------------
   Every mod you drop into the /mods folder needs one entry here, or the
   browser won't know about it.

   Each entry:
     id       unique, no spaces.
     name     shows on the card.
     author   shows under the name. Use "Unknown" if you don't know.
     desc     one or two sentences. Keep it short, cards look better.
     tags     array of strings. These build the filter row automatically.
     file     path to the .js mod file, relative to this launcher.
     icon     optional image path. Leave it out and you get the first letter.
     sample   delete this line once it's a real mod. It just marks the card
              so you can tell which ones are still placeholders.

   The four below are templates showing the shape. Replace them with your
   actual EaglerForge mods.
   ========================================================================== */

window.EL_MODS = [
  {
    id: "example-zoom",
    name: "Example: Zoom",
    author: "Replace me",
    desc: "Placeholder card. Swap in one of your own mods and delete the sample flag.",
    tags: ["Utility"],
    file: "mods/example-zoom.js",
    sample: true
  },
  {
    id: "example-hud",
    name: "Example: Coordinates HUD",
    author: "Replace me",
    desc: "Placeholder card. Shows how a second entry stacks in the grid.",
    tags: ["HUD", "Utility"],
    file: "mods/example-hud.js",
    sample: true
  },
  {
    id: "example-shaders",
    name: "Example: Visual tweak",
    author: "Replace me",
    desc: "Placeholder card. Tags you invent here show up as filter chips.",
    tags: ["Visual"],
    file: "mods/example-shaders.js",
    sample: true
  },
  {
    id: "example-world",
    name: "Example: World tool",
    author: "Replace me",
    desc: "Placeholder card. Delete all four of these once your real list is in.",
    tags: ["World"],
    file: "mods/example-world.js",
    sample: true
  }
];
