/* ============================================================================
   VERSIONS
   ----------------------------------------------------------------------------
   This is the list you edit when you add or rename a game build.

   Each entry:
     id       unique, no spaces. Also used to remember your last pick.
     name     what shows in the list and the dropdown.
     desc     one short line under the name.
     section  "vanilla" or "modded". Decides which tab it appears in.
     path     where the game's index.html lives, relative to this launcher.
     forge    true if this build can load EaglerForge mods.

   Paths are case sensitive on GitHub Pages. Keep folder names lowercase.
   ========================================================================== */

window.EL_VERSIONS = [
  {
    id: "eaglercraft-1.8",
    name: "Eaglercraft 1.8",
    desc: "The classic PvP version",
    section: "vanilla",
    path: "versions/eaglercraft-1.8/index.html",
    forge: false
  },
  {
    id: "eaglercraft-1.12.2",
    name: "Eaglercraft 1.12.2",
    desc: "Later survival version",
    section: "vanilla",
    path: "versions/eaglercraft-1.12.2/index.html",
    forge: false
  },
  {
    id: "eaglercraft-26.1.2",
    name: "Eaglercraft 26.1.2",
    desc: "Newest build",
    section: "vanilla",
    path: "versions/eaglercraft-26.1.2/index.html",
    forge: false
  },
  {
    id: "eaglerforge",
    name: "EaglerForge",
    desc: "Mod loader. Everything in the mod browser runs here.",
    section: "modded",
    path: "versions/eaglerforge/index.html",
    forge: true
  }
];
