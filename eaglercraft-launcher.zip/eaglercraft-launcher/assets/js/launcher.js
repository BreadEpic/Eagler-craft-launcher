/* ============================================================================
   Eaglercraft Launcher
   ----------------------------------------------------------------------------
   Nothing in here needs editing to add content. Add versions in
   data/versions.js and mods in data/mods.js.
   ========================================================================== */

(function () {
  "use strict";

  var VERSIONS = window.EL_VERSIONS || [];
  var CATALOG  = window.EL_MODS || [];

  /* ---- storage -------------------------------------------------------- */

  var KEY = {
    section:  "eagler-launcher:section",
    lastVer:  "eagler-launcher:lastVersion",
    active:   "eagler-launcher:activeMods",
    imported: "eagler-launcher:importedMods",
    settings: "eagler-launcher:settings",
    handoff:  "eaglerforge:mods"          // read by versions/eaglerforge/mod-bridge.js
  };

  function load(key, fallback) {
    try {
      var raw = localStorage.getItem(key);
      return raw === null ? fallback : JSON.parse(raw);
    } catch (e) { return fallback; }
  }

  function save(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); return true; }
    catch (e) { toast("Couldn't save. Storage is full or blocked."); return false; }
  }

  /* ---- state ---------------------------------------------------------- */

  var settings = load(KEY.settings, { embed: true, remember: true });
  var imported = load(KEY.imported, []);   // { id, name, author, desc, tags, code }
  var active   = load(KEY.active, []);     // array of mod ids, in load order
  var section  = load(KEY.section, "vanilla");
  var lastVer  = load(KEY.lastVer, {});    // { vanilla: id, modded: id }

  var filterTag = null;
  var query = "";
  var sortBy = "name";

  /* ---- shorthands ----------------------------------------------------- */

  function $(id) { return document.getElementById(id); }
  function el(tag, cls) { var n = document.createElement(tag); if (cls) n.className = cls; return n; }
  function txt(s) { return document.createTextNode(s == null ? "" : String(s)); }

  var toastTimer;
  function toast(message) {
    var t = $("toast");
    t.textContent = message;
    t.classList.add("is-up");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function () { t.classList.remove("is-up"); }, 2600);
  }

  function allMods() { return CATALOG.concat(imported); }
  function modById(id) {
    var list = allMods();
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }
  function versionsIn(sec) {
    return VERSIONS.filter(function (v) { return v.section === sec; });
  }

  /* ======================================================================
     Sections
     ==================================================================== */

  function showSection(name) {
    section = name;
    save(KEY.section, name);

    ["vanilla", "modded"].forEach(function (s) {
      var on = s === name;
      var tab = $("tab-" + s);
      var panel = $("panel-" + s);
      tab.setAttribute("aria-selected", on ? "true" : "false");
      panel.classList.toggle("is-hidden", !on);
      panel.hidden = !on;
      panel.classList.toggle("panel--modded", s === "modded");
    });
  }

  /* ======================================================================
     Versions
     ==================================================================== */

  function renderVersions(sec) {
    var list = versionsIn(sec);
    var ul = $("verlist-" + sec);          // the Modded panel has no list, only a dropdown
    var select = $("select-" + sec);
    var counter = $("count-" + sec);

    if (ul) ul.textContent = "";
    if (select) select.textContent = "";

    if (!list.length) {
      if (ul) {
        var li = el("li");
        var note = el("p", "empty__body");
        note.appendChild(txt("Nothing listed yet. Add an entry in data/versions.js."));
        li.appendChild(note);
        ul.appendChild(li);
      }
      if (counter) counter.textContent = "0 installed";
      return;
    }

    var chosen = pickVersion(sec);

    list.forEach(function (v) {
      /* card, when the panel has room for one */
      if (ul) {
        var li = el("li");
        var btn = el("button", "ver");
        btn.type = "button";
        btn.setAttribute("aria-current", v.id === chosen ? "true" : "false");
        btn.dataset.id = v.id;

        var cube = el("span", "ver__cube" + (v.forge ? " ver__cube--forge" : ""));
        var text = el("span", "ver__text");
        var name = el("span", "ver__name"); name.appendChild(txt(v.name));
        var desc = el("span", "ver__desc"); desc.appendChild(txt(v.desc || v.path));
        text.appendChild(name); text.appendChild(desc);

        var pill = el("span", "pill " + (v.forge ? "pill--forge" : "pill--ready"));
        pill.appendChild(txt(v.forge ? "Mod loader" : "Ready"));

        btn.appendChild(cube); btn.appendChild(text); btn.appendChild(pill);
        btn.addEventListener("click", function () { setVersion(sec, v.id); });
        li.appendChild(btn);
        ul.appendChild(li);
      }

      /* dropdown */
      if (select) {
        var opt = el("option");
        opt.value = v.id;
        opt.appendChild(txt(v.name));
        if (v.id === chosen) opt.selected = true;
        select.appendChild(opt);
      }
    });

    if (counter) counter.textContent = list.length + " installed";
  }

  function pickVersion(sec) {
    var list = versionsIn(sec);
    if (!list.length) return null;
    var want = settings.remember ? lastVer[sec] : null;
    for (var i = 0; i < list.length; i++) if (list[i].id === want) return want;
    return list[0].id;
  }

  function setVersion(sec, id) {
    lastVer[sec] = id;
    save(KEY.lastVer, lastVer);
    renderVersions(sec);
    updateHints();
  }

  /* ======================================================================
     Mod browser
     ==================================================================== */

  function renderTags() {
    var box = $("mod-tags");
    box.textContent = "";

    var seen = {};
    allMods().forEach(function (m) {
      (m.tags || []).forEach(function (t) { seen[t] = true; });
    });
    var tags = Object.keys(seen).sort();
    if (!tags.length) return;

    var all = chip("All", filterTag === null);
    all.addEventListener("click", function () { filterTag = null; renderTags(); renderMods(); });
    box.appendChild(all);

    tags.forEach(function (t) {
      var c = chip(t, filterTag === t);
      c.addEventListener("click", function () {
        filterTag = (filterTag === t) ? null : t;
        renderTags(); renderMods();
      });
      box.appendChild(c);
    });
  }

  function chip(label, on) {
    var b = el("button", "chip");
    b.type = "button";
    b.setAttribute("aria-pressed", on ? "true" : "false");
    b.appendChild(txt(label));
    return b;
  }

  function visibleMods() {
    var q = query.trim().toLowerCase();

    var list = allMods().filter(function (m) {
      if (filterTag && (m.tags || []).indexOf(filterTag) === -1) return false;
      if (!q) return true;
      var hay = [m.name, m.author, m.desc].concat(m.tags || []).join(" ").toLowerCase();
      return hay.indexOf(q) !== -1;
    });

    list.sort(function (a, b) {
      if (sortBy === "added") {
        var d = (active.indexOf(b.id) !== -1) - (active.indexOf(a.id) !== -1);
        if (d) return d;
      }
      if (sortBy === "author") {
        var av = (a.author || "").toLowerCase(), bv = (b.author || "").toLowerCase();
        if (av !== bv) return av < bv ? -1 : 1;
      }
      return (a.name || "").toLowerCase() < (b.name || "").toLowerCase() ? -1 : 1;
    });

    return list;
  }

  function renderMods() {
    var grid = $("modgrid");
    grid.textContent = "";

    var list = visibleMods();
    $("mod-empty").classList.toggle("is-hidden", list.length > 0);

    list.forEach(function (m) {
      var on = active.indexOf(m.id) !== -1;

      var card = el("article", "mod" + (on ? " is-on" : ""));

      var top = el("div", "mod__top");
      var icon = el("div", "mod__icon");
      if (m.icon) {
        var img = el("img");
        img.src = m.icon;
        img.alt = "";
        icon.appendChild(img);
      } else {
        icon.appendChild(txt((m.name || "?").charAt(0).toUpperCase()));
      }

      var idBox = el("div", "mod__id");
      var name = el("h3", "mod__name"); name.appendChild(txt(m.name));
      var by = el("p", "mod__by"); by.appendChild(txt(m.author ? "by " + m.author : "Imported file"));
      idBox.appendChild(name); idBox.appendChild(by);

      top.appendChild(icon); top.appendChild(idBox);

      var desc = el("p", "mod__desc");
      desc.appendChild(txt(m.desc || ""));

      var foot = el("div", "mod__foot");
      var tags = el("div", "mod__tags");
      (m.tags || []).slice(0, 3).forEach(function (t) {
        var tg = el("span", "tag"); tg.appendChild(txt(t)); tags.appendChild(tg);
      });
      if (m.sample) {
        var s = el("span", "tag tag--sample"); s.appendChild(txt("Sample")); tags.appendChild(s);
      }
      if (m.code) {
        var im = el("span", "tag"); im.appendChild(txt("Imported")); tags.appendChild(im);
      }

      var add = el("button", "addbtn" + (on ? " is-on" : ""));
      add.type = "button";
      add.appendChild(txt(on ? "Added" : "Add"));
      add.addEventListener("click", function () { toggleMod(m.id); });
      add.addEventListener("mouseenter", function () { if (on) { add.textContent = "Remove"; } });
      add.addEventListener("mouseleave", function () { if (on) { add.textContent = "Added"; } });

      foot.appendChild(tags); foot.appendChild(add);

      card.appendChild(top);
      card.appendChild(desc);
      card.appendChild(foot);
      grid.appendChild(card);
    });

    $("count-mods").textContent = allMods().length + " available, " + active.length + " added";
  }

  function toggleMod(id) {
    var i = active.indexOf(id);
    if (i === -1) active.push(id); else active.splice(i, 1);
    save(KEY.active, active);
    renderMods();
    updateHints();
  }

  /* ---- importing local .js files -------------------------------------- */

  function importFiles(files) {
    var added = 0;
    var pending = files.length;
    if (!pending) return;

    Array.prototype.forEach.call(files, function (file) {
      if (!/\.js$/i.test(file.name)) {
        pending--;
        return;
      }
      var reader = new FileReader();
      reader.onload = function () {
        var id = "imported:" + file.name.replace(/\.js$/i, "");
        if (!modById(id)) {
          imported.push({
            id: id,
            name: file.name.replace(/\.js$/i, ""),
            author: "",
            desc: "Imported from your device. It is stored in this browser only.",
            tags: ["Imported"],
            code: String(reader.result)
          });
          added++;
        }
        if (--pending === 0) finish();
      };
      reader.onerror = function () { if (--pending === 0) finish(); };
      reader.readAsText(file);
    });

    function finish() {
      save(KEY.imported, imported);
      renderTags(); renderMods();
      toast(added ? added + (added === 1 ? " mod imported" : " mods imported") : "Nothing new to import");
    }
  }

  /* ======================================================================
     Launching
     ==================================================================== */

  function buildPayload() {
    return active.map(function (id) {
      var m = modById(id);
      if (!m) return null;
      return m.code
        ? { id: m.id, name: m.name, code: m.code }
        : { id: m.id, name: m.name, src: m.file };
    }).filter(Boolean);
  }

  function launch(sec) {
    var id = $("select-" + sec).value;
    var v = null;
    for (var i = 0; i < VERSIONS.length; i++) if (VERSIONS[i].id === id) v = VERSIONS[i];
    if (!v) { toast("Pick a version first."); return; }

    var url = v.path;
    var payload = [];

    if (v.forge) {
      payload = buildPayload();
      save(KEY.handoff, payload);
      var srcOnly = payload.filter(function (p) { return p.src; }).map(function (p) { return p.src; });
      if (srcOnly.length) {
        url += (url.indexOf("?") === -1 ? "?" : "&") + "mods=" + encodeURIComponent(srcOnly.join(","));
      }
    } else {
      save(KEY.handoff, []);
    }

    lastVer[sec] = v.id;
    save(KEY.lastVer, lastVer);

    if (!settings.embed) {
      window.open(url, "_blank", "noopener");
      return;
    }

    var stage = $("game-stage");
    stage.textContent = "";

    var frame = el("iframe");
    frame.src = url;
    frame.allow = "fullscreen; autoplay; gamepad; clipboard-write; pointer-lock";
    frame.setAttribute("allowfullscreen", "");
    frame.addEventListener("load", function () {
      /* second delivery route, in case the game page listens for messages */
      try {
        frame.contentWindow.postMessage({ type: "eagler-launcher:mods", mods: payload }, "*");
      } catch (e) { /* cross origin, ignore */ }
    });

    stage.appendChild(frame);
    $("game-now").textContent = v.name + (payload.length ? "  ·  " + payload.length + " mods" : "");
    $("game").classList.remove("is-hidden");
    $("game").hidden = false;
    document.getElementById("app").setAttribute("aria-hidden", "true");
  }

  function quitGame() {
    $("game-stage").textContent = "";
    $("game").classList.add("is-hidden");
    $("game").hidden = true;
    document.getElementById("app").removeAttribute("aria-hidden");
    if (document.fullscreenElement) document.exitFullscreen();
  }

  /* ======================================================================
     Hints and counts
     ==================================================================== */

  function updateHints() {
    var vh = $("hint-vanilla");
    var vv = versionsIn("vanilla").length;
    vh.textContent = vv
      ? "No mods here. This is the plain game."
      : "Add a version in data/versions.js to get started.";

    var mh = $("hint-modded");
    var badge = $("play-badge");
    if (!active.length) {
      mh.textContent = "No mods added. EaglerForge will start clean.";
      badge.hidden = true;
    } else {
      mh.textContent = active.length === 1
        ? "1 mod will load"
        : active.length + " mods will load";
      badge.textContent = String(active.length);
      badge.hidden = false;
    }

    $("play-vanilla").disabled = !versionsIn("vanilla").length;
    $("play-modded").disabled = !versionsIn("modded").length;
  }

  /* ======================================================================
     Settings
     ==================================================================== */

  function openModal() {
    $("set-embed").checked = !!settings.embed;
    $("set-remember").checked = !!settings.remember;
    $("modal").classList.remove("is-hidden");
    $("modal").hidden = false;
  }

  function closeModal() {
    $("modal").classList.add("is-hidden");
    $("modal").hidden = true;
  }

  /* ======================================================================
     Wiring
     ==================================================================== */

  function init() {
    /* banners: fall back to the bundled placeholder if a custom one is missing */
    ["vanilla", "modded"].forEach(function (s) {
      var img = $("banner-" + s);
      var custom = "images/" + s + "-banner.png";
      var probe = new Image();
      probe.onload = function () { img.src = custom; };
      probe.src = custom;
      img.addEventListener("error", function () { img.src = "images/" + s + "-banner.svg"; });
    });

    document.querySelectorAll(".tab").forEach(function (t) {
      t.addEventListener("click", function () { showSection(t.dataset.section); });
    });

    ["vanilla", "modded"].forEach(function (s) {
      $("select-" + s).addEventListener("change", function () { setVersion(s, this.value); });
      $("play-" + s).addEventListener("click", function () { launch(s); });
    });

    $("mod-search").addEventListener("input", function () { query = this.value; renderMods(); });
    $("mod-sort").addEventListener("change", function () { sortBy = this.value; renderMods(); });

    $("btn-import").addEventListener("click", function () { $("file-import").click(); });
    $("file-import").addEventListener("change", function () { importFiles(this.files); this.value = ""; });

    $("btn-quit").addEventListener("click", quitGame);
    $("btn-full").addEventListener("click", function () {
      var g = $("game");
      if (document.fullscreenElement) document.exitFullscreen();
      else if (g.requestFullscreen) g.requestFullscreen();
    });

    $("btn-settings").addEventListener("click", openModal);
    $("modal").addEventListener("click", function (e) {
      if (e.target.hasAttribute("data-close")) closeModal();
    });

    $("set-embed").addEventListener("change", function () {
      settings.embed = this.checked; save(KEY.settings, settings);
    });
    $("set-remember").addEventListener("change", function () {
      settings.remember = this.checked; save(KEY.settings, settings);
    });

    $("btn-reset").addEventListener("click", function () {
      if (!confirm("Clear your added mods, imported files, and settings?")) return;
      Object.keys(KEY).forEach(function (k) { localStorage.removeItem(KEY[k]); });
      location.reload();
    });

    document.addEventListener("keydown", function (e) {
      if (e.key !== "Escape") return;
      if (!$("modal").hidden) closeModal();
    });

    /* drag and drop .js mods anywhere */
    var depth = 0;
    var drop = $("drop");
    function showDrop(on) {
      drop.classList.toggle("is-hidden", !on);
      drop.hidden = !on;
    }
    window.addEventListener("dragenter", function (e) {
      e.preventDefault(); depth++; showDrop(true);
    });
    window.addEventListener("dragover", function (e) { e.preventDefault(); });
    window.addEventListener("dragleave", function () { if (--depth <= 0) { depth = 0; showDrop(false); } });
    window.addEventListener("drop", function (e) {
      e.preventDefault(); depth = 0; showDrop(false);
      if (e.dataTransfer && e.dataTransfer.files.length) {
        showSection("modded");
        importFiles(e.dataTransfer.files);
      }
    });

    /* first paint */
    showSection(section === "modded" ? "modded" : "vanilla");
    renderVersions("vanilla");
    renderVersions("modded");
    renderTags();
    renderMods();
    updateHints();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
