# fonts

Optional. Put a pixel font here named `pixel.ttf` or `pixel.woff2` and the
launcher picks it up automatically for headings and buttons.

Without one it falls back to a monospace stack, which still looks fine.

Use a font you're allowed to redistribute.
