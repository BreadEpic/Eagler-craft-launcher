/* example-zoom.js — placeholder mod file.

   This exists so the sample card in the mod browser has something to point
   at. Delete it once you drop in your real EaglerForge mods, and remove the
   matching entry from data/mods.js.

   A real mod goes here as normal JavaScript. The launcher just loads the
   file; whatever API your EaglerForge build exposes is what you write
   against. */

console.log("[mod] example-zoom loaded");
