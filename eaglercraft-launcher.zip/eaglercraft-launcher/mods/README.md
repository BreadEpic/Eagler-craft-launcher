# mods

Put your EaglerForge mod `.js` files in this folder.

Then add a matching entry in `data/mods.js` so the mod browser knows it
exists. Copy one of the blocks that's already in there and change the values:

```js
{
  id: "zoom",
  name: "Zoom",
  author: "SomeDev",
  desc: "Hold C to zoom in.",
  tags: ["Utility"],
  file: "mods/zoom.js"
}
```

Notes:

- `id` has to be unique and have no spaces.
- `file` is the path from the launcher root, so it starts with `mods/`.
- Whatever you put in `tags` becomes a filter chip automatically.
- Add `icon: "images/mods/zoom.png"` if you want a picture instead of a letter.
- Delete the four `example-*` files and their entries once you have real mods.

You can also drag a `.js` file onto the launcher window to add it on the fly.
Those are stored in your browser only, so they won't show up for anyone else
visiting the site.
